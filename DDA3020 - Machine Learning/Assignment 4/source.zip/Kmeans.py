import numpy as np
import pandas as pd

def kmeansInit(x, c, r):
    
    for i in range(0, x.shape[0]):
        y = 10000
        z = 0
        
        for k in range(0, len(c)):
            if y > np.linalg.norm((x[i]-c[k])**2):
                y = np.linalg.norm((x[i]-c[k])**2)
                z = k
        r[i] = [0] * len(c)
        r[i][z] = 1
    return r

def kmeansRefit(x, c, r):
    for k in range(0, len(c)):
        a=0
        b=0
        for i in range(0, x.shape[0]):
            #print(r[i][k], x[i])
            a = a + r[i][k]*x[i]
            
        for i in range(0, x.shape[0]):
            b = b + r[i][k]
        
        if b==0:
            b=1

        #print(" - ", np.linalg.norm(c[k] - a/b))
        c[k] = a/b        
    return c

def norm(x):
    result = 0
    for i in x:
        result = result + i**2
    return result**(1/2)

data = pd.read_csv('seeds_dataset.txt',sep='\t+',engine='python').to_numpy()
trainX, trainY = np.hsplit(data, [7])

c=[trainX[0], trainX[100], trainX[200]]
r = [[0] * len(c)] *trainX.shape[0]

#Activate
for i in range(0, 50):
    r = kmeansInit(trainX, c, r)
    c = kmeansRefit(trainX, c, r)

for i in range(0, len(r)):
    if r[i]==[1,0,0]:
        r[i]=1
    elif r[i]==[0,1,0]:
        r[i]=2
    else:
        r[i]=3

acc = 0
for i in range(0, len(r)):
    if int(r[i]) == int(trainY[i]):
        acc = acc+1

print("*Accuracy:", (acc/len(r))*100) # Accuracy

#Sihlouette Coef
print("\n*Sihlouette Coefficient")
for i in range(0, len(trainX)):
    a = [np.linalg.norm(trainX[i] - c[0]), np.linalg.norm(trainX[i] - c[1]), np.linalg.norm(trainX[i] - c[2])]
    a.sort()
    print("point %d:" %(i+1), (a[1]-a[0]) / a[1])
    
#Rand Index
print("\n*Rand Index")
c2=[trainX[20], trainX[130], trainX[170]]
r2 = [[0] * len(c2)] *trainX.shape[0]

for i in range(0, 50):
    r2 = kmeansInit(trainX, c2, r2)
    c2 = kmeansRefit(trainX, c2, r2)

for i in range(0, len(r)):
    if r2[i]==[1,0,0]:
        r2[i]=1
    elif r2[i]==[0,1,0]:
        r2[i]=2
    else:
        r2[i]=3

acc = 0
for i in range(0, len(r)):
    if int(r2[i]) == int(trainY[i]):
        acc = acc+1

rand = 0
for i in range(0, len(r)):
    if (r[i]==int(trainY[i]) and r2[i]==int(trainY[i])) or (r[i]!=int(trainY[i]) and r2[i]!=int(trainY[i])):
        rand = rand + 1

print(rand / len(r))


