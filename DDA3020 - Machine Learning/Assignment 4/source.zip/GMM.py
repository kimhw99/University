import csv
import math

trainX=[]
trainY=[]




f = open('seeds_dataset.txt', 'r')
for i in f:
    i = i.replace("\t\t", "\t")
    trainX = trainX + [(i.split("\t"))[:-1]]
    trainY = trainY + [int((i.split("\t"))[-1])]
f.close()

for i in range (0, len(trainX)):
    for j in range (0, len(trainX[0])):
        trainX[i][j] = float(trainX[i][j])

mean = [0] * len(trainX[0])
variance = [0] * len(trainX[0])

for i in range (0, len(trainX)): #means
    for j in range (0, len(trainX[0])):
        mean[j] = mean[j] + trainX[i][j]

for i in range (0, len(trainX[0])):
    mean[i] = mean[i] / len(trainX)

for i in range (0, len(trainX)): #variance
    for j in range (0, len(trainX[0])):
        variance[j] = variance[j] + (trainX[i][j]-mean[j])**2

for i in range (0, len(trainX[0])):
    variance[i] = variance[i] / len(trainX)

weights = [1] * len(trainX[0]) #weights

def pdf(x, u, m):
    return (1/((2*math.pi*m)**(1/2)))*math.exp( (-(x-u)**2)/(2*m) )

def norm(x):
    result = 0
    for i in x:
        result = result + i**2
    return result**(1/2)

def gmmE(x, m, v, w):
    r=[]
    for n in range (0, len(x)):
        rk=[]
        rksum = 0
        for k in range (0, len(x[0])):
            rksum = rksum + w[k] * pdf(norm(x[n]), m[k], v[k])
            
        for k in range (0, len(x[0])):
            rk = rk + [ (w[k] * pdf(x[n][k], m[k], v[k])) / rksum]

        r = r + [rk]
    return r

def gmmM(x, r):
    m = [0] * len(x[0])
    v = [0] * len(x[0])
    w = [0] * len(x[0])
    Nk = [0] * len(responsibility[0])

    for i in responsibility: #Nk
        for j in range (0, len(i)):
            Nk[j] = Nk[j] + i[j]

    for i in range (0, len(x)): #means
        for j in range (0, len(x[0])):
            m[j] = m[j] + norm(r[i]) * norm(x[i])

    for i in range (0, len(x[0])):
        m[i] = m[i] / (1/Nk[i])

    for i in range (0, len(x)): #variance
        for j in range (0, len(x[0])):
            v[j] = v[j] + norm(r[i]) * (norm(x[i]) - m[j]) * (norm(x[i]) - m[j])

    for i in range (0, len(x[0])):
        v[i] = v[i] / (1/Nk[i])

    for i in range (0, len(x[0])): #weights
        w[i] = Nk[i] / sum(Nk) #len(x[0])

    return [m, v, w]

def logLikelihood(x, p, u, m):
    result = 0
    for i in range(0, len(x)):
        resulti = 0
        for j in range (0, len(x[0])):
            resulti = resulti + p[j] * pdf(norm(x[i]), u[j], m[j])
        
        result = result + math.log(resulti)

    return result

result = 0 #check for log likelihood convergence

while result!=logLikelihood(trainX, weights, mean, variance):
    result=logLikelihood(trainX, weights, mean, variance)
    responsibility = gmmE(trainX, mean, variance, weights)
    [mean, variance, weights] = gmmM(trainX, responsibility)
    print(logLikelihood(trainX, weights, mean, variance)) #prints log likelihood until convergence










