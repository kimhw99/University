1. Unzip Group 20 - Supplementary.zip and place it into a folder
2. Download the PyTorch Model and place it into the same folder (https://drive.google.com/file/d/11seOjWcbB-eV0C_YRfvHH77uY1I2xSen/view?usp=sharing)
3. run Run_Program.py
4. Once the UI is displayed, type a sentence to be analyzed and click “analyze”
5. The model will predict the input sentence as a positive or negative sentence
6. Clicking on “Click For More Detail” will display the probabilities for each sentiment
7. Notebooks used for testing & training can be found in the model_build folder