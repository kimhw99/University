import PySimpleGUI as sg
import  bertModel as bert
import numpy as np 
import os

try:
    positive = [os.path.join("resource", "sentiment-very-satisfied.png"), os.path.join("resource", "thumbs-up.png")]
    negative = [os.path.join("resource", "sentiment-dissatisfied.png"), os.path.join("resource", "thumbs-down.png")]
    # positive = [".\\resource\\sentiment-very-satisfied.png",".\\resource\\thumbs-up.png"]
    # negative = [".\\resource\\sentiment-dissatisfied.png",".\\resource\\thumbs-down.png"]
    colour = '#3B3B3B'
    # ico = ".\\resource\\download.ico"
    ico = os.path.join("resource","download.ico")
    ico = os.path.join(os.path.curdir, ico)

    result = [sg.Image(key = "-1result-", background_color= colour), sg.Image(key = "-2result-", background_color= colour)]
    detail = sg.Text(key = "-detail-",background_color= colour, enable_events=True, font = ("", 9, "underline"))

    header = sg.Text("Sentiment Analysis", background_color= colour, font = ("", 16, "bold"))
    inputBox = sg.Input(size = 70, enable_events=True, key = "-input-", expand_x=False, justification='left'),
    button = sg.Button("analyze", key="-button-", button_color="#4D5157", font = ("", 9, ""))


    layout = [[sg.Push(background_color = colour),header,sg.Push(background_color = colour)],[sg.Push(background_color = colour)],[sg.Push(background_color = colour)],[sg.Push(background_color = colour)],
            [inputBox],[sg.Push(background_color = colour)],[sg.Push(background_color = colour),button,sg.Push(background_color = colour)],
            [sg.Push(background_color = colour)],[sg.Push(background_color = colour)],[sg.Push(background_color = colour)],[sg.Push(background_color = colour)],
            [sg.Push(background_color = colour),] + result + [sg.Push(background_color = colour),],[sg.Push(background_color = colour)],
            [sg.Push(background_color = colour),detail,sg.Push(background_color = colour)]]

    window = sg.Window(title="CSC3180 Project", layout = layout, size = (300,300), margins=(25,25), background_color = colour, icon = ico)


    result = None
    while True:
        event, value = window.read()

        if event == "-detail-":
            _positive = "Positive Sentiment - "+ str(result[0]) + "%"
            _negative = "Negative Sentiment - "+ str(result[1]) + "%"
            sg.popup_no_buttons(_positive, _negative, title = "Detail", background_color = colour,grab_anywhere = True, keep_on_top = True, no_titlebar = False, icon = ico)

        if event == "-button-":
            temp = bert.analyze(value["-input-"])
            result = temp

            if np.argmax(temp) == 0:
                for i in range(2):
                    key = "-"+ str(i+1)+"result-"
                    path = os.path.join(os.path.curdir, positive[i])
                    window[key].update(path)
            else:
                for i in range(2):
                    key = "-"+ str(i+1)+"result-"
                    path = os.path.join(os.path.curdir, negative[i])
                    window[key].update(path)

            window["-detail-"].update("Click For More Detail")
        
        if event == sg.WIN_CLOSED:
            break

    window.close()

except:
    print("Run \"requirement.py\" to install dependencies")
    print("Before Running the program")